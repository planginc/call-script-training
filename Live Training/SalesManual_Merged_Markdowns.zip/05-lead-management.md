---
title: "Lead Management"
section: "05"
description: "Lead profiles, sources, assignments, phases, and qualifying signals."
---

# Lead Profile
Overview based on marketing funnels. (PDF content pending.)

## Assigning Leads
(From PDF.)

## Lead Sources
(From PDF.)

## Marketing Tiers
(From PDF.)

## Lead Phases
(From PDF.)

## Qualifying
- Early categorize: behind vs current. Shapes budget focus and objection handling.【23†source】

## BBB Ratings
(From PDF.)

## Key Takeaways
- Balance same day closes with pipeline follow up.【23†source】

## Compliance Notes
> Stay consultative. No pressure tactics or misleading claims. UDAAP awareness at all times.【23†source】
