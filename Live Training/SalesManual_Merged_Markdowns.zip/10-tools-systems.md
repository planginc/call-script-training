---
title: "Tools and Systems"
section: "10"
description: "Texting, inactivating leads, phone system use, voicemail, and scripts."
---

# Texting Leads
(Use PDF guidance.)

## Inactivating Leads
(Use PDF guidance.)

## InContact System
- Productive vs unavailable time targets. Make notes between calls without going unavailable when possible.【23†source】

## Voicemail Guidelines
(Use PDF scripts.)

## Sample Scripts
- Use **voluntarily discontinue payments** wording when applicable.【23†source】

## Key Takeaways
- Keep productive rate high by minimizing unnecessary unavailable time.【23†source】

## Compliance Notes
> Scripts with legal or regulatory disclosures must be preserved verbatim from the PDF.
